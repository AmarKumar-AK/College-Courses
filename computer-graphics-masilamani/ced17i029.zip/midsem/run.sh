g++ test.cpp -lGL -lGLU -lglut -o test
./test