g++ q2.cpp -lGL -lGLU -lglut -o test
./test