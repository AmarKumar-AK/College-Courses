import sys
from InstructionClass import instructions
from FunctionalUnit import FunctionalUnit

ASM_FILE = sys.argv[1] 
new_instr_flag = False
global_queue = []

class ScoreboardParser:
	def __init__(self, asm_file):
		self.scoreboard_instance = Scoreboard()
		self.asm_file = asm_file

	def asm_file_parser(asm_file):
		parser = ScoreboardParser(asm_file)
		with open(parser.asm_file, 'r') as file_handle:
			print(file_handle)
			assembly = list(map(lambda x: x.strip(), file_handle))
		for line in assembly:
			parser.__parse_line(line)
		return parser.scoreboard_instance
			# for fu in parser.scoreboard_instance.fu:
			# 	print(fu.fu_type)

	def __parse_line(self, instruction):
		tokens = instruction.split()
		if tokens[0][0] == '.':
			self.__parse_fu(tokens)
		else:
			self.__parse_instruction(tokens)

	def __parse_fu(self, tokens):
		fu_type = tokens[0][1:]
		no_of_units = int(tokens[1])
		clock_cycle = int(tokens[2])
		for no in range(0, no_of_units):
			self.scoreboard_instance.fu.append(FunctionalUnit(fu_type, clock_cycle))

	def __parse_instruction(self, tokens):
		inst = tokens[0]
		inst_func = instructions[inst]
		tokenized_inst = inst_func(' '.join(tokens))
		self.scoreboard_instance.instr.append(tokenized_inst)

class Scoreboard:

	def __init__(self):
		self.fu = []
		self.instr = []
		self.pc = 0
		self.clock = 1
		self.register_status = {}

	def complete(self):
		execution_complete = True
		remaining_instr = not self.has_remaining_instr()
		# print(self.clock, self.pc, remaining_instr)
		if remaining_instr:
			for f in self.fu:
				if f.busy:
					remaining_instr = False
					break
		return execution_complete and remaining_instr

	def has_remaining_instr(self):
		return self.pc < len(self.instr)

	def fu_can_issue(self, fu, inst):
		if inst:
			return not fu.busy and inst.unit == fu.fu_type and not (inst.fi in self.register_status)

		return False

	def issue_to_fu(self, fu, next_instruction):
		fu.issue(next_instruction, self.register_status)
		self.register_status[next_instruction.fi] = fu
		# print(next_instruction.inst, self.register_status)
		next_instruction.issue = self.clock
		fu.inst_pc = self.pc

	def fu_can_read(self, fu):
		return fu.busy and fu.rj and fu.rk

	def read_to_fu(self, fu):
		fu.read_operands()
		self.instr[fu.inst_pc].read_ops = self.clock

	def fu_can_exec(self, fu):
		return (not fu.rj and not fu.rk) and fu.issued()

	def exec_by_fu(self, fu):
		fu.execute()
		if fu.clock == 0:
			self.instr[fu.inst_pc].ex_cmplt = self.clock

	def fu_can_write(self, fu):
		can_write_back = False
		for f in self.fu:
			# Check for WAR before write back
			can_write_back = (f.fj != fu.fi or not f.rj) and (f.fk != fu.fi or not f.rk)
			# print(f.fj, f.fk, not f.rj, not f.rk, fu.fi)
			# print(can_write_back)
			if not can_write_back:
				break
		return can_write_back

	def write_back(self, fu):
		fu.write_back(self.fu)
		self.instr[fu.inst_pc].write_back = self.clock
		del self.register_status[fu.fi]
		fu.clear()
		
	def check_for_waw(prev_inst, current_inst):
		pass

	def tick(self):
		global new_instr_flag
		for f in self.fu:
			f.lock = False

		next_instruction = self.instr[self.pc] if self.has_remaining_instr() else None

		for fu in self.fu:
			if self.fu_can_issue(fu, next_instruction): # Check for structural hazard and WAW
				self.issue_to_fu(fu, next_instruction)
				self.pc+=1
				fu.lock = True
				new_instr_flag = True
			elif self.fu_can_read(fu):
				self.read_to_fu(fu)
				fu.lock = True
			elif self.fu_can_exec(fu):
				self.exec_by_fu(fu)
				fu.lock = True
			elif fu.issued():
				fu.lock = True

		# if not new_instr_flag:
		# 	global_queue.append(next_instruction)
		# 	if self.has_remaining_instr():
		# 		temp_pc = self.pc + 1
		# 		new_instruction = self.instr[temp_pc]
		# 		for instr in global_queue:
		# 			check_for_waw()
		# 		for fu in self.fu:
		# 			if self.fu_can_issue(fu, new_instruction):
		# 				pass

		for fu in self.fu:
			if not fu.lock and self.fu_can_write(fu):
				self.write_back(fu)

		self.clock += 1

if __name__ == "__main__":
	sb = ScoreboardParser.asm_file_parser(ASM_FILE)
	while not sb.complete():
		sb.tick()

	"%-30s%-10d%-15d%-20d%-15d"
	print(' Instruction               | Issue | Read Operands | Execution Complete | Write Results')
	for instr in sb.instr:
		print(str(instr))