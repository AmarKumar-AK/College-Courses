g++ q1.cpp -lGL -lGLU -lglut -o test
./test